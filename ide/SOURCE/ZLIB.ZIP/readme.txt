ZLIB Support
------------

This example shows how to use the library ZLIBSUPP.DLL. This library is
an Xbase++ wrapper to the compression library ZLIB.DLL that supports 
GZIP file format.

To create the test program:
 
- using Xbase++ 1.3  rename the file ZLIB13.DLL  in ZLIBSUPP.DLL, or
  using Xbase++ 1.5  rename the file ZLIB15.DLL  in ZLIBSUPP.DLL, or
  using Xbase++ 1.6  rename the file ZLIB16.DLL  in ZLIBSUPP.DLL, or
  using Xbase++ 1.7  rename the file ZLIB17.DLL  in ZLIBSUPP.DLL, or
  using Xbase++ 1.8  rename the file ZLIB18.DLL  in ZLIBSUPP.DLL, or
  using Xbase++ 1.82 rename the file ZLIB182.DLL in ZLIBSUPP.DLL

- run PBUILD TESTZ.XPJ


To test the program run 
  TESTZ readme.txt readme.gz readme.out

This will create the files README.GZ that is the file README.TXT in
compressed format and the file README.OUT that is the file README.GZ 
decompressed (so is identical to the original file README.TXT)

For further information see the file TESTZ.PRG 

To include the library in a dBsee project include the file 
ZLIBSUPP.LIB in external library from Menu Entity -> Library

For further information on ZLIB.DLL library see the official web site
http://www.gzip.org/zlib/ or http://www.winimage.com/zLibDll
