This folder contains the files in RTF format that describes
the forms

Example

MENU.RTF   will be showed pressing F1 when the user is in the
           MENU.PRG form
LOGON.RTF  will be showed pressing F1 when the user is in the
           LOGON.PRG form

The .RTF files are to be manually written using for example WORD 
and saving the file in .RTF format 

Notes:

- To be correctly processed, the RTF files must have notes that
  to set the name and description of the Topic. This information
  are used by Microsoft Help Workshop; for further info see the
  Microsoft Help Workshop Help and examples in folder 
  ..\RTF-EXAMPLE

- Files in RTF format created with WORD 97 or previous cannot be
  used directly, they are to be "fixed" using the utility 
  Easy Fix RTF downloadable from
  http://www.helpmaster.com/hlp-developmentaids-easyfixrtf.htm
