This folder contains example files to create the help.

MENU.RTF   will be showed pressing F1 when the user is in the
           MENU.PRG form
LOGON.RTF  will be showed pressing F1 when the user is in the
           LOGON.PRG form

If these files are open with WORD it is possible to see other 
information that are used by Microsoft Help Workshop to identify
the ID and title of the documents. This information are stored
as footnotes and are needed to create the help file.
