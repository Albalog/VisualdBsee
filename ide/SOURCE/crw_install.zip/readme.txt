=======================================================
Deploy Reports created with Crystal Reports 9 or higher
=======================================================

Starting with version 9 of Crystal Reports, the procedure to deploy
reports is changed and the copy of DLL is no more valid.

To install the runtime of Crystal Reports follow this steps:

Installing the runtime of Crystal Reports 9
-------------------------------------------
1) Extact the file CRW_Install.zip that is located in the folder
   SOURCE\ of dBsee for Xbase++ in a temporary folder.

2) Copy the .dll files (usually are located in the Crystal Reports
   installation folder or in the common files folder 
   c:\program files\common files\crystal decisions)
   in the temporary folder.
     craxddrt.dll
     craxdrt9.dll
     crdb_p2bxbse.dll
     crpe32.dll
     crqe.dll
     crviewer9.dll
     Implode.dll
     keycode.dll
     querybuilder.dll
     ufmanager.dll

3) From MSDOS Prompt, run the file CRW9_REG.BAT <common files path>
    CRW9_REG  "c:\program files\common files\crystal decisions\2.0\bin"  

4) Launch Regedit and verify that the 
   HKEY_LOCAL_MACHINE\SOFTWARE\Crystal Decisions\9.0\Crystal Reports 
   contains the path specified in point 3

5) Verify that the path specified in point 3 is contained in the 
   system path. Eventually add it to the system path.

 
Installing the runtime of Crystal Reports 10
--------------------------------------------
1) Extact the file CRW_Install.zip that is located in the folder
   SOURCE\ of dBsee for Xbase++ in a temporary folder.

2) Copy the .dll files (usually are located in the Crystal Reports
   installation folder or in the common files folder 
   c:\program files\common files\crystal decisions)
   in the temporary folder.
     crqe.dll
     ufmanager.dll
     crviewer.dll
     craxdrt.dll
     Craxddrt.Dll
     keycode.dll
     crpe32.dll
     crdb_p2bxbse.dll
     querybuilder.dll
     Implode.dll

3) From MSDOS Prompt, run the file CRW10_REG.BAT <common files path>
    CRW10_REG  "c:\program files\common files\crystal decisions\2.5\bin"  

4) Launch Regedit and verify that the 
   HKEY_LOCAL_MACHINE\SOFTWARE\Crystal Decisions\10.0\Crystal Reports 
   contains the path specified in point 3

5) Verify that the path specified in point 3 is contained in the 
   system path. Eventually add it to the system path.

