Questa cartella deve contenere i files in formato RTF 
che descrivono le form.

Esempio

MENU.RTF   verra chiamato premendo F1 quando l'utente � nella
           form MENU.PRG
LOGON.RTF  verra chiamato premendo F1 quando l'utente � nella
           form LOGON.PRG

I files .RTF vanno scritti manualmente usando ad esempio WORD e 
salvando in formato .RTF invece che .DOC

Note:

- Per essere processati correttamente, i files RTF devono avere
  delle note che indicano il nome e la descrizione del TOPIC che
  vengono usate da Microsoft Help Workshop; per maggiori 
  informazioni vedere l'help di Microsoft Help Workshop e gli 
  esempi nella cartella ..\RTF-ESEMPI

- I files in formato RTF creati da WORD 97 o precedenti 
  non possono essere usati direttamente, ma vanno prima "fissati"
  usando l'utility Easy Fix RTF scaricabile da 
  http://www.helpmaster.com/hlp-developmentaids-easyfixrtf.htm
