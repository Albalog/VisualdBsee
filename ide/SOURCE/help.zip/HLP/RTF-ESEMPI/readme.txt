Questi cartella contiene dei files di esempio da usare per creare l'help.

MENU.RTF   verra chiamato premendo F1 quando l'utente � nella
           form MENU.PRG
LOGON.RTF  verra chiamato premendo F1 quando l'utente � nella
           form LOGON.PRG

Se vengono aperti con WORD � possibile visualizzare i dati aggiuntivi
che vengono usati da Microsoft Help Workshop per identificare 
l'ID e il titolo del documento scegliendo da WORD,  menu "Visualizza"
la voce "Note a pi� di pagina"
Questi dati messi nelle note a pi� di pagina sono indispensabili 
per creare il file di help.